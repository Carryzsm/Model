// 包含了多个状态数据的对象
export default {
}