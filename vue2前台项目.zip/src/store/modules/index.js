import home from './home'
import search from './search'
import detail from './detail'
import shopcart from './shopcart'
import user from './user'
import order from './order'
export default {
  home,
  search,
  detail,
  shopcart,
  user,
  order
}