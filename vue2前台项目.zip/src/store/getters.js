// 包含了多个状态数据的计算属性的get方法的对象
export default {}