// // 包含了多个间接修改状态数据的方法的对象
export default {
  // xxx(){
  //   console.log('我是总的action')
  // }
}