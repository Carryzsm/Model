// 包含了多个直接修改状态数据的方法的对象
export default {}