// 引入Vue
import Vue from 'vue'
// 引入那个玩意
import VueAwesomeSwiper from 'vue-awesome-swiper'
// 引入swiper相关的样式
import 'swiper/css/swiper.css'
// 声明使用插件
Vue.use(VueAwesomeSwiper)