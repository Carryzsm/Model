<template>
  <div>Test2组件界面</div>
</template>
<script lang="ts">
export default {
  name: 'Test2'
}
</script>
<script lang="ts" setup>
</script>
<style scoped>
</style>