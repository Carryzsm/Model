// 枚举类型的标识
export enum ShowStatus {
  SPU_LIST = 1,
  SPU_ADD = 2,
  SKU_ADD = 3
}