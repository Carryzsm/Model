<template>
  <div>分类界面</div>
</template>
<script lang="ts">
export default {
  name: 'Category'
}
</script>
<script lang="ts" setup>
</script>
<style scoped>
</style>